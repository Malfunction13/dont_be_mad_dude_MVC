<?php
set_include_path('C:\Users\User\PhpstormProjects\dont_be_mad_dude_MVC');
require 'models/Player.php';
require 'models/Board.php';


function makePlayer($team): Player
{

    return new Player($team);
}

function makeBoard() : Board {
    $gameField = array_fill(0, 15, array_fill(0, 15, ["  "]));
    drawField($gameField);
    drawFinish($gameField);

    return new Board($gameField);
}


function drawField(array &$field) {
    $middle = floor(count($field) / 2);

    // The below without &$row doesnt change $board at all
    foreach ($field as &$row) {
        $row[$middle-1] = ["..", ];
        $row[$middle] = ["..", ];
        $row[$middle+1] = ["..", ];

    }
    unset($row);

    foreach ($field as $index=>&$row){

        if ($index == $middle-1  || $index == $middle || $index == $middle+1) {

            foreach($field[$index] as &$cols) {
                $cols = ["..", ];
            }
        }
    }
    unset($row);
    unset($cols);
}

function drawFinish(array &$field) {
    $middle = floor(count($field) / 2);

    // finish line horizontal
    foreach ($field[$middle] as $index => &$col) {
        if ($index != 0 && $index != count($field)-1) {
            $col = ["FF", ];
        }
    }
    unset($horizontal);

    // finish line vertical
    foreach ($field as $index => &$row) {
        if ($index != 0 && $index != count($field)-1) {
            $row[$middle] = ["FF", ];
        }

    }
}