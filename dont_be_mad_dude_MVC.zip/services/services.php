<?php
set_include_path('C:\Users\User\PhpstormProjects\dont_be_mad_dude_MVC');
require 'models/Figure.php';




// GETTERS

function getMiddle(array $field) : int {

    return intval(floor(count($field)/2));
}


function getLast(array $field) : int{

    return count($field)-1;
}


function allowedToSpawn (Player $player) : bool {
    if (count($player->figures) + $player->finishedCount < 4) {

        return true;
    } else {

        return false;
    }
}


function findFreeName(Player $player) : string {
    $ownedFigures = [];
    foreach ($player->figures as $figure) {
        array_push($ownedFigures, $figure->name);
        }

    for ($i = 1; $i <= 4; $i++) {
        $name = $player->team . $i;
        if (!in_array($name, $ownedFigures)) {

            return $name;
        }
    }
}


function findPlayerKeyByName (Board $board, string $pName) : int {
    foreach ($board->players as $key => $player) {
        echo "\n", "LOOKING TO FIND $pName IN KEY $key, VALUE $player->team";
        if ($player->team == $pName) {
            echo "\n", "SUCCESS RETURNING $key";
            return $key;
        }
    }
}


function findPlayerByFig(Board $board, string $figName) : int {
    // loop through all players and their figures until u find the same figure name as the passed $name
    foreach ($board->players as $key => $player) {
        foreach ($player->figures as $figure){
            if ($figure->name === $figName) {

                return $key;
            }
        }
    }
}


function findFigureKey(Board $board, string $name) : int {
    // loop through all players and their figures until u find the same figure name as the passed $name
    foreach ($board->players as $player) {
        foreach ($player->figures as $key=>$figure){
            if ($figure->name === $name) {

                return $key;
            }
        }
    }
}


function getFigureNames (array $figuresList) : array {
    $namesList = [];
    foreach ($figuresList as $figure) {
        array_push($namesList, $figure->name);
    }

    return $namesList;
}


function findEnemies (array $namesList, string $exclusion) : bool|array {    // ['R1', 'G1', 'Y1', 'G2', 'B1], 'R'
    $nonFriendly = preventFriendlyFire($namesList, $exclusion); // ['G1', 'Y1', 'G2', 'B1]
    if (count($nonFriendly) === 0) { //if after removing friendly units
        return false; // no collision because all units there were your own - no point to check further
        //an empty array can also be returned and it would evaluate to false in if($nonFriendly) statement
    }

    //otherwise check the list of remaining names for fortified units - 2+figures of the same team render all figs invincible
    return findVictims($nonFriendly); // ['Y1', 'B1']
}


function preventFriendlyFire (array $namesList, string $exclusion) : array {
    foreach ($namesList as $key=>$figure) {
        if ($figure[0] == $exclusion) {
            unset($namesList[$key]); // retaining the order of keys in local variable is not important here
        }
    }

    return $namesList;
}


function findVictims ($targets) {
    $enemiesCounter = [
        "R" => 0,
        "G" => 0,
        "B" => 0,
        "Y" => 0,
    ];

    foreach ($targets as $figure) { // keep track of the occurence of figures from each team
        if (in_array($figure[0], array_keys($enemiesCounter))) { // if the figure's team (G) finds a match in the enemies counter
            $enemiesCounter[$figure[0]]++; // increment 1
        }
    }

    $singles = findSingles($enemiesCounter); // ['Y', 'B']
    $victims = findTargets($targets, $singles); // will remove from ['G1', 'Y1', 'G2', 'B1] all that is not of Y or B team

    return $victims; // ['Y1', 'B1']
}


function findSingles (array $enemiesCounter) : array {
    $victimsList = [];
    foreach ($enemiesCounter as $team => $count) { // we can attack only single figures
        if ($count === 1) {
            array_push($victimsList, $team); // so we add the team tags to list of potential victims
        }
    }
    return $victimsList;
}


function findTargets (array $initialList, array $victimsList) : array {
    $targets = $initialList;
    foreach ($targets as $key => $figure) { // finally we know which teams have exposed figures
        if (in_array($figure[0], $victimsList) === false) { // from the original list of figures
            unset($initialList[$key]); // remove the figures absent in the victims list (0 or 2+ figs)
        }
    }
    return $targets;
}


// SETTERS

function changeCurrentPlayer (Board $board)
{
    $previousPlayerKey = $board->currentPlayer;
    //if the current player was last in the list
    if ($previousPlayerKey >= array_key_last($board->players)) { //OR he was deleted (eg player 4 deleted, now biggest key is 3 or 2)
        $board->currentPlayer = array_key_first($board->players); // set currentPlayer to the the first
    } else { // if he wasnt last, the finished player might've been first or in the middle
        $checkedKey = $previousPlayerKey+1; // we dont know if the next in order exists at all
        while (!array_key_exists($checkedKey, $board->players)) // if it was player1's turn and player2 already finished
            $checkedKey ++; //, the loop would try player3 and so on until finds a key that is bigger than the current and exists
        $board->currentPlayer = $checkedKey;
    }
}


function setCompass(string $team) : string {
    switch ($team) {
        case "R":

            return "W";

        case "G":

            return "N";

        case "B":

            return "E";

        case "Y":

            return "S";
    }
}


function updateCompass(Board $board, Figure $figure)
{
    $breakPoints = [
        "W" =>  ["y" => getMiddle($board->field),
            "x" => 0],

        "N" =>  ["y" => 0,
            "x" => getMiddle($board->field)],

        "E" =>  ["y" => getMiddle($board->field),
            "x" => getLast($board->field)],

        "S" =>  ["y" => getLast($board->field),
            "x" => getMiddle($board->field)],
    ];

    if ($figure->y == $breakPoints["W"]["y"] && $figure->x == $breakPoints["W"]["x"]) {
        if ($board->players[$board->currentPlayer]->team === "R") { #red players at this breakpoint can move to the finish line
            $figure->compass = "F";
        } else {
            $figure->compass = "W";
        }
    } elseif ($figure->y == $breakPoints["N"]["y"] && $figure->x == $breakPoints["N"]["x"]) {
        if ($board->players[$board->currentPlayer]->team === "G") { #green players at this breakpoint can move to the finish line
            $figure->compass = "F";
        } else {
            $figure->compass = "N";
        }
    } elseif ($figure->y == $breakPoints["E"]["y"] && $figure->x == $breakPoints["E"]["x"]) {
        if ($board->players[$board->currentPlayer]->team === "B") {
            $figure->compass = "F";
        } else {
            $figure->compass = "E";
        }
    } elseif ($figure->y == $breakPoints["S"]["y"] && $figure->x == $breakPoints["S"]["x"]) {
        if ($board->players[$board->currentPlayer]->team === "Y") {
            $figure->compass = "F";
        } else {
            $figure->compass = "S";
        }
    }
}



//Position update functions only change the representation on board, the collision controller has done all the rest
function newPosUpdate(array &$field, Figure $figure, bool|string $collision) {
    if ($collision) {
        if ($collision == "F") { //finishing condition
            //do nothing because at the finishing spot the figure gets deleted
        } else { // if there is standard collision
            $key = array_search($collision, $field[$figure->y][$figure->x]); // seek
            array_splice($field[$figure->y][$figure->x], $key, 1); // and destroy
            array_push($field[$figure->y][$figure->x], $figure->name); //occupy slot
        }
    } else { // if there is no collision we have a free tile or occupied by our own figures tile
        if ($field[$figure->y][$figure->x][0] === ".." || $field[$figure->y][$figure->x][0] === "FF") {
            array_splice($field[$figure->y][$figure->x], 0, 1); //remove the free tile
            array_push($field[$figure->y][$figure->x], $figure->name); // step on it
        } else {
            array_push($field[$figure->y][$figure->x], $figure->name);
        }

    }
}


function oldPosUpdate(Board $board, int $oldY, int $oldX)
{
    $key = array_search($board->players[$board->currentPlayer]->currentFigure->name, $board->field[$oldY][$oldX]); //find the key for the currentPlayers figure on old position
    array_splice($board->field[$oldY][$oldX],$key,1); //remove using that key

    $last = getLast($board->field);
    $middle = getMiddle($board->field);

    if (count($board->field[$oldY][$oldX]) === 0) { //if the array remains empty
        //if the old coordinates are on the finish lines
        if ($oldY == $middle && ($oldX > 0 && $oldX < $last)) {
            //horizontal line
            array_push($board->field[$oldY][$oldX], "FF"); // fill the empty slot with a FF marker
        } elseif ($oldX == $middle && ($oldY > 0 && $oldY < $last)) {
            //this is the vertical finish line
            array_push($board->field[$oldY][$oldX], "FF");
        } else { // if the tile is not within the finish line than its a casual free tile
            array_push($board->field[$oldY][$oldX], ".."); // add a free tile marker
        }
    }
}


// CREATORS


function createFigure(Player $player, array $starterCoords) : Figure
{
    $name = findFreeName($player);
    $y = $starterCoords[0];
    $x = $starterCoords[1];
    $compass = setCompass($player->team);

    return new Figure($name, $y, $x, $compass);
}


// REMOVERS

function removeFigure(Board $board, string $figName)
{
    $playerKey = findPlayerByFig($board, $figName); // loop through all players and their figures until u find the same figure name as hitFigure
    $figureKey = findFigureKey($board, $figName);
    array_splice($board->players[$playerKey]->figures, $figureKey, 1);
}


function removePlayer(Board $board)
{

    unset($board->players[$board->currentPlayer]);
}


// STATUS

function isFinishedFigure(Board $board) : bool
{
    $middle = getMiddle($board->field);
    if ($board->players[$board->currentPlayer]->currentFigure->y == $middle &&
        $board->players[$board->currentPlayer]->currentFigure->x == $middle) {

        return true;
    }

    return false;
}


function isFinishedPlayer(Player $player) : bool
{
    if ($player->finishedCount === 4) { // if the player

        return true;
    }
    return false;
}


// MOVEMENT

function movementController(Board $board, Figure $figure)
{
    switch ($figure->compass) {
        case "W":
            moveWest($board, $figure);
            break;

        case "N":
            moveNorth($board, $figure);
            break;

        case "E":
            moveEast($board, $figure);
            break;

        case "S":
            moveSouth($board, $figure);
            break;

        case "F":
            moveFinish($board, $figure);
            break;

    }
}


// Movement functions only modify the objects Y, X
// West never looks left and down
function moveWest (Board $board, Figure $figure)
{
    if (array_key_exists($figure->y-1, $board->field) && $board->field[$figure->y-1][$figure->x][0] != "  ") {
        $figure->y --; // change the X coordinate in the figure obj accordingly
    } elseif ($board->field[$figure->y][$figure->x+1][0] != "  ") {
        $figure->x ++;
    }
}


// North never looks left and up
function moveNorth (Board $board, Figure $figure)
{
    if (array_key_exists($figure->x+1, $board->field[$figure->y]) &&
        $board->field[$figure->y][$figure->x+1][0] != "  ") {
        $figure->x ++; // change the X coordinate in the figure obj accordingly
    } elseif ($board->field[$figure->y+1][$figure->x][0] != "  ") {
        $figure->y ++;
    }

}


function moveEast (Board $board, Figure $figure)
{
    if (array_key_exists($figure->y+1, $board->field)  && $board->field[$figure->y+1][$figure->x][0] != "  ") {
        $figure->y ++; // change the X coordinate in the figure obj accordingly
    } elseif ($board->field[$figure->y][$figure->x-1][0] != "  "){
        $figure->x --;
    }
}


// South never right and down
function moveSouth (Board $board, Figure $figure) {
    if (array_key_exists($figure->x-1, $board->field[$figure->y]) && $board->field[$figure->y][$figure->x-1][0] != "  ") {
        $figure->x --; // change the X coordinate in the figure obj accordingly
    } elseif ($board->field[$figure->y-1][$figure->x][0] != "  "){
        $figure->y --;
    }
}


function moveFinish (Board $board, Figure $figure)
{
    if ($figure->compass === "F" && $board->players[$board->currentPlayer]->team === "R") {
        $figure->x ++;
    } elseif ($figure->compass === "F" && $board->players[$board->currentPlayer]->team === "G") {
        $figure->y ++;
    } elseif ($figure->compass === "F" && $board->players[$board->currentPlayer]->team === "B") {
        $figure->x --;
    } elseif ($figure->compass === "F" && $board->players[$board->currentPlayer]->team === "Y") {
        $figure->y --;
    }
}






