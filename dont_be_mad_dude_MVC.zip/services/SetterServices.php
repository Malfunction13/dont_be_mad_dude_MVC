<?php


class SetterServices
{
    function changeCurrentPlayer (object $board)
    {
        $previousPlayerKey = $board->currentPlayer;
        //if the current player was last in the list
        if ($previousPlayerKey >= array_key_last($board->players)) { //OR he was deleted (eg player 4 deleted, now biggest key is 3 or 2)
            $board->currentPlayer = array_key_first($board->players); // set currentPlayer to the the first
        } else { // if he wasnt last, the finished player might've been first or in the middle
            $checkedKey = $previousPlayerKey+1; // we dont know if the next in order exists at all
            while (!array_key_exists($checkedKey, $board->players)) // if it was player1's turn and player2 already finished
                $checkedKey ++; //, the loop would try player3 and so on until finds a key that is bigger than the current and exists
            $board->currentPlayer = $checkedKey;
        }
    }




    function setCompass(string $team) : string
    {
        switch ($team) {
            case "R":

                return "W";

            case "G":

                return "N";

            case "B":

                return "E";

            case "Y":

                return "S";
        }
    }


    function updateCompass(object $board, object $figure) {
        $breakPoints = [
            "W" =>  ["y" => getMiddle($board->field),
                "x" => 0],

            "N" =>  ["y" => 0,
                "x" => getMiddle($board->field)],

            "E" =>  ["y" => getMiddle($board->field),
                "x" => getLast($board->field)],

            "S" =>  ["y" => getLast($board->field),
                "x" => getMiddle($board->field)],
        ];

        if ($figure->y == $breakPoints["W"]["y"] && $figure->x == $breakPoints["W"]["x"]) {
            if ($board->players[$board->currentPlayer]->team === "R") { #red players at this breakpoint can move to the finish line
                $figure->compass = "F";
            } else {
                $figure->compass = "W";
            }
        } elseif ($figure->y == $breakPoints["N"]["y"] && $figure->x == $breakPoints["N"]["x"]) {
            if ($board->players[$board->currentPlayer]->team === "G") { #green players at this breakpoint can move to the finish line
                $figure->compass = "F";
            } else {
                $figure->compass = "N";
            }
        } elseif ($figure->y == $breakPoints["E"]["y"] && $figure->x == $breakPoints["E"]["x"]) {
            if ($board->players[$board->currentPlayer]->team === "B") {
                $figure->compass = "F";
            } else {
                $figure->compass = "E";
            }
        } elseif ($figure->y == $breakPoints["S"]["y"] && $figure->x == $breakPoints["S"]["x"]) {
            if ($board->players[$board->currentPlayer]->team === "Y") {
                $figure->compass = "F";
            } else {
                $figure->compass = "S";
            }
        }
    }



//Position update functions only change the representation on board, the collision controller has done all the rest
    function newPosUpdate(array &$field, object $figure, bool|string $collision) {
        if ($collision) {
            if ($collision == "F") { //finishing condition
                //do nothing because at the finishing spot the figure gets deleted
            } else { // if there is standard collision
                $key = array_search($collision, $field[$figure->y][$figure->x]); // seek
                array_splice($field[$figure->y][$figure->x], $key, 1); // and destroy
                array_push($field[$figure->y][$figure->x], $figure->name); //occupy slot
            }
        } else { // if there is no collision we have a free tile or occupied by our own figures tile
            if ($field[$figure->y][$figure->x][0] === ".." || $field[$figure->y][$figure->x][0] === "FF") {
                array_splice($field[$figure->y][$figure->x], 0, 1); //remove the free tile
                array_push($field[$figure->y][$figure->x], $figure->name); // step on it
            } else {
                array_push($field[$figure->y][$figure->x], $figure->name);
            }

        }
    }


    function oldPosUpdate(object $board, int $oldY, int $oldX) {
        $key = array_search($board->players[$board->currentPlayer]->currentFigure->name, $board->field[$oldY][$oldX]); //find the key for the currentPlayers figure on old position
        array_splice($board->field[$oldY][$oldX],$key,1); //remove using that key

        $last = getLast($board->field);
        $middle = getMiddle($board->field);

        if (count($board->field[$oldY][$oldX]) === 0) { //if the array remains empty
            //if the old coordinates are on the finish lines
            if ($oldY == $middle && ($oldX > 0 && $oldX < $last)) {
                //horizontal line
                array_push($board->field[$oldY][$oldX], "FF"); // fill the empty slot with a FF marker
            } elseif ($oldX == $middle && ($oldY > 0 && $oldY < $last)) {
                //this is the vertical finish line
                array_push($board->field[$oldY][$oldX], "FF");
            } else { // if the tile is not within the finish line than its a casual free tile
                array_push($board->field[$oldY][$oldX], ".."); // add a free tile marker
            }
        }
    }
}