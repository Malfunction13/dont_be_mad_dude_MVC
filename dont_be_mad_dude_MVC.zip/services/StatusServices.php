<?php


class StatusServices
{
    function allowedToSpawn (object $player) : bool
    {
        if (count($player->figures) + $player->finishedCount < 4) {

            return true;
        } else {

            return false;
        }
    }

    function isFinishedFigure(Board $board) : bool
    {
        $middle = getMiddle($board->field);
        if ($board->players[$board->currentPlayer]->currentFigure->y == $middle &&
            $board->players[$board->currentPlayer]->currentFigure->x == $middle) {

            return true;
        }

        return false;
    }


    function isFinishedPlayer(Player $player) : bool
    {
        if ($player->finishedCount === 4) { // if the player

            return true;
        }
        return false;
    }
}