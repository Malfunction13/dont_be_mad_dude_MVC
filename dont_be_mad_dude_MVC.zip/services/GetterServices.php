<?php


class GetterServices {
    function getMiddle(array $field) : int {

        return intval(floor(count($field)/2));
    }


    function getLast(array $field) : int{

        return count($field)-1;
    }


    function findFreeName(object $player) : string {
        $ownedFigures = [];
        foreach ($player->figures as $figure) {
            array_push($ownedFigures, $figure->name);
        }

        for ($i = 1; $i <= 4; $i++) {
            $name = $player->team . $i;
            if (!in_array($name, $ownedFigures)) {

                return $name;
            }
        }
    }


    function findPlayerKeyByName (object $board, string $pName) : int {
        foreach ($board->players as $key => $player) {
            echo "\n", "LOOKING TO FIND $pName IN KEY $key, VALUE $player->team";
            if ($player->team == $pName) {
                echo "\n", "SUCCESS RETURNING $key";
                return $key;
            }
        }
    }


    function findPlayerByFig(object $board, string $figName) : int {
        // loop through all players and their figures until u find the same figure name as the passed $name
        foreach ($board->players as $key => $player) {
            foreach ($player->figures as $figure){
                if ($figure->name === $figName) {

                    return $key;
                }
            }
        }
    }


    function findFigureKey(object $board, string $name) : int {
        // loop through all players and their figures until u find the same figure name as the passed $name
        foreach ($board->players as $player) {
            foreach ($player->figures as $key=>$figure){
                if ($figure->name === $name) {

                    return $key;
                }
            }
        }
    }


    function getFigureNames (array $figuresList) : array {
        $namesList = [];
        foreach ($figuresList as $figure) {
            array_push($namesList, $figure->name);
        }

        return $namesList;
    }


    function findEnemies (array $namesList, string $exclusion) : bool|array {    // ['R1', 'G1', 'Y1', 'G2', 'B1], 'R'
        $nonFriendly = preventFriendlyFire($namesList, $exclusion); // ['G1', 'Y1', 'G2', 'B1]
        if (count($nonFriendly) === 0) { //if after removing friendly units
            return false; // no collision because all units there were your own - no point to check further
            //an empty array can also be returned and it would evaluate to false in if($nonFriendly) statement
        }

        //otherwise check the list of remaining names for fortified units - 2+figures of the same team render all figs invincible
        return findVictims($nonFriendly); // ['Y1', 'B1']
    }


    function preventFriendlyFire (array $namesList, string $exclusion) : array {
        foreach ($namesList as $key=>$figure) {
            if ($figure[0] == $exclusion) {
                unset($namesList[$key]); // retaining the order of keys in local variable is not important here
            }
        }

        return $namesList;
    }


    function findVictims ($targets) {
        $enemiesCounter = [
            "R" => 0,
            "G" => 0,
            "B" => 0,
            "Y" => 0,
        ];

        foreach ($targets as $figure) { // keep track of the occurence of figures from each team
            if (in_array($figure[0], array_keys($enemiesCounter))) { // if the figure's team (G) finds a match in the enemies counter
                $enemiesCounter[$figure[0]]++; // increment 1
            }
        }

        $singles = findSingles($enemiesCounter); // ['Y', 'B']
        $victims = findTargets($targets, $singles); // will remove from ['G1', 'Y1', 'G2', 'B1] all that is not of Y or B team

        return $victims; // ['Y1', 'B1']
    }


    function findSingles (array $enemiesCounter) : array {
        $victimsList = [];
        foreach ($enemiesCounter as $team => $count) { // we can attack only single figures
            if ($count === 1) {
                array_push($victimsList, $team); // so we add the team tags to list of potential victims
            }
        }
        return $victimsList;
    }


    function findTargets (array $initialList, array $victimsList) : array {
        $targets = $initialList;
        foreach ($targets as $key => $figure) { // finally we know which teams have exposed figures
            if (in_array($figure[0], $victimsList) === false) { // from the original list of figures
                unset($initialList[$key]); // remove the figures absent in the victims list (0 or 2+ figs)
            }
        }
        return $targets;
    }
}