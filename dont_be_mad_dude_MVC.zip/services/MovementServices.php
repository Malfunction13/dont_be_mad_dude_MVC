<?php


class MovementServices
{
    function movementController(Board $board, Figure $figure)
    {
        switch ($figure->compass) {
            case "W":
                moveWest($board, $figure);
                break;

            case "N":
                moveNorth($board, $figure);
                break;

            case "E":
                moveEast($board, $figure);
                break;

            case "S":
                moveSouth($board, $figure);
                break;

            case "F":
                moveFinish($board, $figure);
                break;

        }
    }


    // Movement functions only modify the objects Y, X
    // West never looks left and down
    function moveWest (Board $board, Figure $figure)
    {
        if (array_key_exists($figure->y-1, $board->field) && $board->field[$figure->y-1][$figure->x][0] != "  ") {
            $figure->y --; // change the X coordinate in the figure obj accordingly
        } elseif ($board->field[$figure->y][$figure->x+1][0] != "  ") {
            $figure->x ++;
        }
    }


    // North never looks left and up
    function moveNorth (Board $board, Figure $figure)
    {
        if (array_key_exists($figure->x+1, $board->field[$figure->y]) &&
            $board->field[$figure->y][$figure->x+1][0] != "  ") {
            $figure->x ++; // change the X coordinate in the figure obj accordingly
        } elseif ($board->field[$figure->y+1][$figure->x][0] != "  ") {
            $figure->y ++;
        }

    }


    function moveEast (Board $board, Figure $figure)
    {
        if (array_key_exists($figure->y+1, $board->field)  && $board->field[$figure->y+1][$figure->x][0] != "  ") {
            $figure->y ++; // change the X coordinate in the figure obj accordingly
        } elseif ($board->field[$figure->y][$figure->x-1][0] != "  "){
            $figure->x --;
        }
    }


    // South never right and down
    function moveSouth (Board $board, Figure $figure) {
        if (array_key_exists($figure->x-1, $board->field[$figure->y]) && $board->field[$figure->y][$figure->x-1][0] != "  ") {
            $figure->x --; // change the X coordinate in the figure obj accordingly
        } elseif ($board->field[$figure->y-1][$figure->x][0] != "  "){
            $figure->y --;
        }
    }


    function moveFinish (Board $board, Figure $figure)
    {
        if ($figure->compass === "F" && $board->players[$board->currentPlayer]->team === "R") {
            $figure->x ++;
        } elseif ($figure->compass === "F" && $board->players[$board->currentPlayer]->team === "G") {
            $figure->y ++;
        } elseif ($figure->compass === "F" && $board->players[$board->currentPlayer]->team === "B") {
            $figure->x --;
        } elseif ($figure->compass === "F" && $board->players[$board->currentPlayer]->team === "Y") {
            $figure->y --;
        }
    }
}