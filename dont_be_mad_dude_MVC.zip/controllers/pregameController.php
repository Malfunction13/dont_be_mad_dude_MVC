<?php
set_include_path('C:\Users\User\PhpstormProjects\dont_be_mad_dude_MVC');
require "services/pregameServices.php";


class pregameController {
    public Board $board;
    public View $view;


    function __construct(View $view) {
        $this->board = makeBoard();  // creates a 3d array and draws tiles
        $this->view = $view;
    }


    function createPlayers() { // makes Player obj and appends to the board
        $teamsList = ["R", "G", "B", "Y"];
        $playersNum = $this->view->getPlayersNum();

            for ($i = 0; $i < $playersNum; $i++) {
                array_push($this->board->players, makePlayer($teamsList[$i]));
            }
    }


    function setStarterPlayer() {
        $this->board->currentPlayer = 0;
    }


    function getBoard() : Board {
        $this->createPlayers();
        $this->setStarterPlayer();

        return $this->board;
    }
}

