<?php
set_include_path('C:\Users\User\PhpstormProjects\dont_be_mad_dude_MVC');
require 'controllers/gameController.php';
require 'controllers/pregameController.php';
require 'views/View.php';


$view = new View();
$pregameController = new pregameController($view);
$board = $pregameController->getBoard();
$controller = new gameController($board, $view);

function main(object $controller) {
    while (true) {
        if ($controller->isGameOver()) { // exit condition first
             $controller->finalResult();

             break;
        }

        if ($controller->handleTurn()) { // will return false if the player got bonus turn and it is still his turn to play
            $controller->switchPlayer(); // if currPlayer is unchanged on next turn the throw will be for the same player
        }

        $controller->view->printBoard($controller->board->field);
        sleep(2);
    }

}

main($controller);


